#!/usr/bin/env python3

import rospy
import numpy as np
import casadi as ca
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import tf


class TurtleBotMPC:
    def __init__(self):
        rospy.init_node("turtlebot_mpc_node")
        rospy.loginfo("Starting TurtleBot MPC Node...")

        # === Target Goal ===
        self.goal = np.array([
            rospy.get_param("~goal_x", 1.0),
            rospy.get_param("~goal_y", 1.0),
            rospy.get_param("~goal_theta", 0.0)
        ])

        # === Parameters ===
        self.N = 10               # Horizon steps
        self.dt = 0.2             # Timestep
        self.stop_thresh = 0.1    # Distance to goal to stop

        # === ROS Publishers/Subscribers ===
        self.cmd_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        rospy.Subscriber("/odom", Odometry, self.odom_callback)

    def odom_callback(self, msg):
        pos = msg.pose.pose.position
        ori = msg.pose.pose.orientation
        _, _, yaw = tf.transformations.euler_from_quaternion([ori.x, ori.y, ori.z, ori.w])
        state = np.array([pos.x, pos.y, yaw])

        if np.linalg.norm(state[:2] - self.goal[:2]) < self.stop_thresh:
            self.stop_bot()
            return

        v, w = self.solve_mpc(state)
        self.publish_cmd(v, w)

    def stop_bot(self):
        cmd = Twist()
        self.cmd_pub.publish(cmd)

    def publish_cmd(self, v, w):
        cmd = Twist()
        cmd.linear.x = float(v)
        cmd.angular.z = float(w)
        self.cmd_pub.publish(cmd)

    def solve_mpc(self, x0):
        Q = ca.diagcat(10, 10, 1)
        R = ca.diagcat(0.1, 0.1)
        Qf = Q * 10

        x = ca.SX.sym("x")
        y = ca.SX.sym("y")
        theta = ca.SX.sym("theta")
        states = ca.vertcat(x, y, theta)
        n_states = states.numel()

        v = ca.SX.sym("v")
        w = ca.SX.sym("w")
        controls = ca.vertcat(v, w)
        n_controls = controls.numel()

        rhs = ca.vertcat(v * ca.cos(theta), v * ca.sin(theta), w)
        f = ca.Function("f", [states, controls], [rhs])

        X = ca.SX.sym("X", n_states, self.N+1)
        U = ca.SX.sym("U", n_controls, self.N)
        P = ca.SX.sym("P", n_states + n_states)

        obj = 0
        g = []

        X[:, 0] = P[0:3]

        for k in range(self.N):
            st = X[:, k]
            con = U[:, k]
            st_next = X[:, k] + self.dt * f(st, con)
            X[:, k+1] = st_next
            obj += ca.mtimes([(st - P[3:]).T, Q, (st - P[3:])]) + ca.mtimes([con.T, R, con])

        obj += ca.mtimes([(X[:, self.N] - P[3:]).T, Qf, (X[:, self.N] - P[3:])])

        OPT_variables = ca.vertcat(ca.reshape(U, -1, 1))
        nlp_prob = {'f': obj, 'x': OPT_variables, 'p': P, 'g': ca.vertcat(*g)}
        solver = ca.nlpsol("solver", "ipopt", nlp_prob)

        lbx = [-0.5] * (self.N * n_controls)
        ubx = [0.5] * (self.N * n_controls)

        args = {
            'lbx': lbx,
            'ubx': ubx,
            'p': np.concatenate((x0, self.goal)),
            'x0': np.zeros(self.N * n_controls)
        }

        sol = solver(**args)
        u_opt = sol['x'].full().flatten()
        return u_opt[0], u_opt[1]


if __name__ == "__main__":
    try:
        TurtleBotMPC()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
